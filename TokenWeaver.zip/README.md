# Instructions

This folder contains material needed to reproduce the results in the paper.
There are three main items:
 1. The folder `/TEE-models` contains the actual formal models to the Tamarin prover, with a dedicated README.
 2. The folder `/PoC` contains the proof-of-concept python code with a dedicated README.
 3. A copy of the specific version of the Tamarin prover that we used (although docker is probably easier, see below) in `tamarin-prover.zip`.

## Using docker to reproduce the formal analysis results

We provide an anonymous docker image via dockerhub with the required pre-installed versions of the tools DeepSec and Tamarin (see below for manual installation).

The image can be fetched via:
```
$ docker pull teeanalysis/provers
```

Then, from this repository, or one that has the `TEE-models` inside of it, please run:
```
 $ docker run -it -v $PWD:/opt/case-studies teeanalysis/provers bash
```

This should result in a shell, where the commands `tamarin-prover` and `deepsec` can be executed, and the README inside the `TEE-models` folder can be followed for further results.

## Compiling the tools from source

This folder also contains the file `tamarin-prover.zip` that contains the source files for the Tamarin prover, with installation instructions at [https://tamarin-prover.github.io/manual/book/002_installation.html].

The DeepSec tool can be obtained and installed via [https://deepsec-prover.github.io/manual/html/install.html].

## Proof of Concept

The proof of concept for the protocol is inside the PoC/ folder, with a dedicated README.
